package com.example.crt;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainURL extends AppCompatActivity {
Button configure;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_url);

        configure = (Button) findViewById(R.id.btn_configure);
        configure.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainURL.this, CompanyLogin.class);
                startActivity(i);
            }
        });
    }
}