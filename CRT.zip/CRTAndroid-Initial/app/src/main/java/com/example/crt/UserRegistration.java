package com.example.crt;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class UserRegistration extends AppCompatActivity {
EditText ed_username,ed_email,ed_password,ed_confirm;
    private Button btn_registration, bt_okImei;
    private boolean bt_submit_status;
    private String str_username, str_password;
    private String userId;
    private String companyId;
    private ImageView iv_sample, iv_show;
    private boolean userStatus;
    private static final int REQUEST_PHONE_STATE = 101;
    String serial;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_registration);

        btn_registration = (Button)findViewById(R.id.btn_register);

        btn_registration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(UserRegistration.this, " Registered successfully!!!", Toast.LENGTH_SHORT).show();
            }
        });


    }
}