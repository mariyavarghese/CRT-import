package com.example.crt;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

public class UserLoginpage extends AppCompatActivity {
Button btn_login,btn_register;
ImageView round;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_login = (Button) findViewById(R.id.btn_login);
        btn_register = (Button)findViewById(R.id.btn_register);
        round = (ImageView)findViewById(R.id.round);


        Glide.with(getApplicationContext())
                .load(R.drawable.user)
                .into(round);

        btn_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(UserLoginpage.this,UserRegistration.class);
                startActivity(i);
            }
        });

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(UserLoginpage.this, " Login successfull !!!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}